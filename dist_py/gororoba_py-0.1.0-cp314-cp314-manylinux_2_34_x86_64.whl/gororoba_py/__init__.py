from .gororoba_py import *

__doc__ = gororoba_py.__doc__
if hasattr(gororoba_py, "__all__"):
    __all__ = gororoba_py.__all__